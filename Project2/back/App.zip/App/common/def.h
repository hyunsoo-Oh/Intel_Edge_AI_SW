
#ifndef COMMON_DEF_H_
#define COMMON_DEF_H_

#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#endif /* COMMON_DEF_H_ */
